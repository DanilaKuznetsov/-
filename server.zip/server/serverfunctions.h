#ifndef SERVERFUNCIONS_H
#define SERVERFUNCIONS_H

#include <QByteArray>
#include <QString>

QByteArray parse(QString data_from_client);

#endif // SERVERFUNCIONS_H
