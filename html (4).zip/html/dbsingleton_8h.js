var dbsingleton_8h =
[
    [ "DataBaseSingletonDestroyer", "class_data_base_singleton_destroyer.html", "class_data_base_singleton_destroyer" ],
    [ "DataBaseSingleton", "class_data_base_singleton.html", "class_data_base_singleton" ],
    [ "DB_NAME", "dbsingleton_8h.html#ab840d057a03e1da1ef1b7e6d63a92d75", null ]
];