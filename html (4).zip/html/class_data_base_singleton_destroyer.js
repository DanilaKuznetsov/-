var class_data_base_singleton_destroyer =
[
    [ "~DataBaseSingletonDestroyer", "class_data_base_singleton_destroyer.html#a876074668afedaf80f24234c2b5869f4", null ],
    [ "initialize", "class_data_base_singleton_destroyer.html#a9222d1848c5dd9c00bc8079cd202a31d", null ]
];