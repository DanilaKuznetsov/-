var class_data_base_singleton =
[
    [ "addFavoriteCity", "class_data_base_singleton.html#a05c155ef628d548382db712352555719", null ],
    [ "auth", "class_data_base_singleton.html#ace10d8d3f8ebba5da7448552e0cb9705", null ],
    [ "getClothingRecommendation", "class_data_base_singleton.html#a1c6b0c4acc93c230f26a31418f2a4b57", null ],
    [ "getCurrentUserLogin", "class_data_base_singleton.html#a4839a7e311325f839d2381fcba3a41b8", null ],
    [ "logout", "class_data_base_singleton.html#a889742b021abb908779d06cca8be0500", null ],
    [ "reg", "class_data_base_singleton.html#a6e13f0611cb2fe944fe914363444afba", null ],
    [ "weather", "class_data_base_singleton.html#a2312df9f3ab4dbe9caff5f3b1299e647", null ],
    [ "DataBaseSingletonDestroyer", "class_data_base_singleton.html#a83154d5b787806cf1d1ae50c7e89256d", null ]
];