var searchData=
[
  ['getclothingrecommendation_0',['getClothingRecommendation',['../class_data_base_singleton.html#a1c6b0c4acc93c230f26a31418f2a4b57',1,'DataBaseSingleton']]],
  ['getcurrentuserlogin_1',['getCurrentUserLogin',['../class_data_base_singleton.html#a4839a7e311325f839d2381fcba3a41b8',1,'DataBaseSingleton']]],
  ['getinstance_2',['getInstance',['../class_data_base_singleton.html#ae1a24c20c524fd67554e1ffe66319ede',1,'DataBaseSingleton']]]
];
