var searchData=
[
  ['initialize_0',['initialize',['../class_data_base_singleton_destroyer.html#a9222d1848c5dd9c00bc8079cd202a31d',1,'DataBaseSingletonDestroyer']]]
];
