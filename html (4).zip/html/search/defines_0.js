var searchData=
[
  ['db_5fname_0',['DB_NAME',['../dbsingleton_8h.html#ab840d057a03e1da1ef1b7e6d63a92d75',1,'dbsingleton.h']]]
];
