var searchData=
[
  ['addfavoritecity_0',['addFavoriteCity',['../class_data_base_singleton.html#a05c155ef628d548382db712352555719',1,'DataBaseSingleton']]],
  ['auth_1',['auth',['../class_data_base_singleton.html#ace10d8d3f8ebba5da7448552e0cb9705',1,'DataBaseSingleton']]]
];
