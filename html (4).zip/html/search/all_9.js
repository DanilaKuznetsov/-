var searchData=
[
  ['weather_0',['weather',['../class_data_base_singleton.html#a2312df9f3ab4dbe9caff5f3b1299e647',1,'DataBaseSingleton']]]
];
