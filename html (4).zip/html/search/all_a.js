var searchData=
[
  ['_7edatabasesingletondestroyer_0',['~DataBaseSingletonDestroyer',['../class_data_base_singleton_destroyer.html#a876074668afedaf80f24234c2b5869f4',1,'DataBaseSingletonDestroyer']]],
  ['_7emytcpserver_1',['~MyTcpServer',['../class_my_tcp_server.html#ab39e651ff7c37c152215c02c225e79ef',1,'MyTcpServer']]]
];
