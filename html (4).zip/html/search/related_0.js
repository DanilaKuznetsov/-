var searchData=
[
  ['databasesingletondestroyer_0',['DataBaseSingletonDestroyer',['../class_data_base_singleton.html#a83154d5b787806cf1d1ae50c7e89256d',1,'DataBaseSingleton']]]
];
