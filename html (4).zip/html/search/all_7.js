var searchData=
[
  ['reg_0',['reg',['../class_data_base_singleton.html#a6e13f0611cb2fe944fe914363444afba',1,'DataBaseSingleton']]]
];
