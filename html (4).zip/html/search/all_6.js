var searchData=
[
  ['parse_0',['parse',['../serverfunctions_8cpp.html#a93e9fd715a2a712a381186a416002db7',1,'parse(QString data_from_client):&#160;serverfunctions.cpp'],['../serverfunctions_8h.html#a93e9fd715a2a712a381186a416002db7',1,'parse(QString data_from_client):&#160;serverfunctions.cpp']]]
];
