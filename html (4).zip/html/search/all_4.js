var searchData=
[
  ['logout_0',['logout',['../class_data_base_singleton.html#a889742b021abb908779d06cca8be0500',1,'DataBaseSingleton']]]
];
