var hierarchy =
[
    [ "DataBaseSingleton", "class_data_base_singleton.html", null ],
    [ "DataBaseSingletonDestroyer", "class_data_base_singleton_destroyer.html", null ],
    [ "QObject", null, [
      [ "MyTcpServer", "class_my_tcp_server.html", null ]
    ] ]
];