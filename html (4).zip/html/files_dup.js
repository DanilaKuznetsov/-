var files_dup =
[
    [ "dbsingleton.cpp", "dbsingleton_8cpp.html", null ],
    [ "dbsingleton.h", "dbsingleton_8h.html", "dbsingleton_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mytcpserv.cpp", "mytcpserv_8cpp.html", null ],
    [ "mytcpserv.h", "mytcpserv_8h.html", "mytcpserv_8h" ],
    [ "serverfunctions.cpp", "serverfunctions_8cpp.html", "serverfunctions_8cpp" ],
    [ "serverfunctions.h", "serverfunctions_8h.html", "serverfunctions_8h" ]
];